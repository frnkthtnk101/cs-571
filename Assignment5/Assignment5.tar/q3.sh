#!/bin/bash
cat $1 | sort -n -k 6
